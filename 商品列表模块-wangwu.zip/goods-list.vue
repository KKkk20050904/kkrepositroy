<template>
  <view class="list-page">
    <!-- 顶部搜索栏 -->
    <view class="search-wrap">
      <input
        class="search-input"
        v-model="keyword"
        placeholder="搜索二手闲置物品"
        confirm-type="search"
        @confirm="onSearch"
      />
      <button class="search-btn" size="mini" @click="onSearch">搜索</button>
    </view>

    <!-- 分类筛选横向滚动栏 -->
    <scroll-view class="category-bar" scroll-x>
      <view
        class="cate-item"
        :class="{ active: currentCate === '' }"
        @click="changeCategory('')"
      >全部</view>
      <view
        v-for="cate in categoryList"
        :key="cate.id"
        class="cate-item"
        :class="{ active: currentCate == cate.id }"
        @click="changeCategory(cate.id)"
      >{{ cate.name }}</view>
    </scroll-view>

    <!-- 商品双列网格 -->
    <view class="goods-grid">
      <view
        v-for="item in goodsList"
        :key="item.id"
        class="goods-card"
        @click="goDetail(item.id)"
      >
        <image class="goods-img" :src="item.image" mode="aspectFill"></image>
        <view class="goods-info">
          <view class="goods-title">{{ item.title }}</view>
          <view class="goods-price">¥{{ item.price }}</view>
        </view>
      </view>
    </view>

    <!-- 底部加载提示 -->
    <view class="load-tip">
      <text v-if="loading">加载中...</text>
      <text v-else-if="noMore">— 没有更多商品了 —</text>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      keyword: '',
      currentCate: '',
      categoryList: [],
      goodsList: [],
      page: 1,
      pageSize: 10,
      loading: false,
      noMore: false
    };
  },
  onLoad() {
    this.getCategoryList();
    this.getGoodsList();
  },
  onReachBottom() {
    if (this.loading || this.noMore) return;
    this.page++;
    this.getGoodsList();
  },
  onPullDownRefresh() {
    this.resetList();
    this.getGoodsList(() => {
      uni.stopPullDownRefresh();
    });
  },
  methods: {
    getCategoryList() {
      uni.request({
        url: 'http://localhost:3000/api/category',
        success: (res) => {
          if (res.data.code === 200) {
            this.categoryList = res.data.data;
          }
        },
        fail: () => {
          this.categoryList = [
            {id:1, name:'书籍教材'},
            {id:2, name:'数码电子'},
            {id:3, name:'宿舍用品'},
            {id:4, name:'服饰鞋包'}
          ];
        }
      });
    },
    getGoodsList(callback) {
      this.loading = true;
      uni.request({
        url: 'http://localhost:3000/api/goods',
        method: 'GET',
        data: {
          page: this.page,
          pageSize: this.pageSize,
          keyword: this.keyword,
          categoryId: this.currentCate
        },
        success: (res) => {
          if (res.data.code === 200) {
            const { list, total } = res.data.data;
            if (this.page === 1) {
              this.goodsList = list;
            } else {
              this.goodsList = [...this.goodsList, ...list];
            }
            this.noMore = this.goodsList.length >= total;
          } else {
            uni.showToast({ title: '加载失败', icon: 'none' });
          }
        },
        fail: () => {
          uni.showToast({ title: '网络错误', icon: 'none' });
        },
        complete: () => {
          this.loading = false;
          callback && callback();
        }
      });
    },
    onSearch() {
      this.resetList();
      this.getGoodsList();
    },
    changeCategory(id) {
      this.currentCate = id;
      this.resetList();
      this.getGoodsList();
    },
    resetList() {
      this.page = 1;
      this.goodsList = [];
      this.noMore = false;
    },
    goDetail(id) {
      uni.navigateTo({
        url: `/pages/goods-detail/goods-detail?id=${id}`
      });
    }
  }
};
</script>

<style scoped>
.list-page { min-height: 100vh; background-color: #f5f6f8; }

.search-wrap {
  display: flex; align-items: center;
  padding: 20rpx; background: #fff;
  position: sticky; top: 0; z-index: 99;
}
.search-input {
  flex: 1; height: 70rpx; padding: 0 24rpx;
  background: #f1f2f4; border-radius: 35rpx; font-size: 28rpx;
}
.search-btn {
  margin-left: 20rpx; height: 70rpx; line-height: 70rpx;
  padding: 0 30rpx; font-size: 28rpx; color: #fff;
  background: #2b85e4; border-radius: 35rpx;
}

.category-bar {
  white-space: nowrap; padding: 16rpx 20rpx;
  background: #fff; border-bottom: 1rpx solid #eee;
}
.cate-item {
  display: inline-block; padding: 10rpx 26rpx; margin-right: 16rpx;
  font-size: 28rpx; color: #666; border-radius: 26rpx; background: #f5f6f8;
}
.cate-item.active { color: #fff; background: #2b85e4; }

.goods-grid {
  display: flex; flex-wrap: wrap;
  justify-content: space-between; padding: 20rpx;
}
.goods-card {
  width: 48.5%; background: #fff; border-radius: 12rpx;
  overflow: hidden; margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.goods-img { width: 100%; height: 320rpx; background: #f0f0f0; }
.goods-info { padding: 16rpx; }
.goods-title {
  font-size: 28rpx; color: #333; line-height: 1.4;
  overflow: hidden; text-overflow: ellipsis;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
}
.goods-price {
  margin-top: 10rpx; font-size: 32rpx;
  color: #ff4d4f; font-weight: bold;
}

.load-tip {
  text-align: center; padding: 30rpx 0 60rpx;
  font-size: 26rpx; color: #999;
}
</style>
