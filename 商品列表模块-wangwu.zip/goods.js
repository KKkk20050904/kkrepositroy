const express = require('express');
const router = express.Router();
const db = require('../db');

/**
 * 商品列表接口
 * GET /api/goods
 * 参数：
 *   page       页码，默认 1
 *   pageSize   每页条数，默认 10
 *   keyword    搜索关键词，模糊匹配标题
 *   categoryId 分类ID，筛选对应分类
 */
router.get('/', (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const pageSize = parseInt(req.query.pageSize) || 10;
  const keyword = req.query.keyword || '';
  const categoryId = req.query.categoryId || '';

  const offset = (page - 1) * pageSize;

  let querySql = `SELECT id, title, price, image, category_id, create_time
                  FROM goods WHERE status = 1`;
  let countSql = `SELECT COUNT(*) AS total FROM goods WHERE status = 1`;
  let queryParams = [];
  let countParams = [];

  // 关键词搜索
  if (keyword) {
    querySql += ' AND title LIKE ?';
    countSql += ' AND title LIKE ?';
    const searchVal = `%${keyword}%`;
    queryParams.push(searchVal);
    countParams.push(searchVal);
  }

  // 分类筛选
  if (categoryId) {
    querySql += ' AND category_id = ?';
    countSql += ' AND category_id = ?';
    queryParams.push(categoryId);
    countParams.push(categoryId);
  }

  querySql += ' ORDER BY create_time DESC LIMIT ? OFFSET ?';
  queryParams.push(pageSize, offset);

  // 先查总数
  db.query(countSql, countParams, (err, countRes) => {
    if (err) {
      console.error('查询总数失败:', err);
      return res.json({ code: 500, msg: '服务器错误', data: null });
    }
    const total = countRes[0].total;

    // 再查分页数据
    db.query(querySql, queryParams, (err, listRes) => {
      if (err) {
        console.error('查询商品列表失败:', err);
        return res.json({ code: 500, msg: '服务器错误', data: null });
      }

      res.json({
        code: 200,
        msg: '获取成功',
        data: {
          list: listRes,
          total: total,
          page: page,
          pageSize: pageSize,
          totalPages: Math.ceil(total / pageSize)
        }
      });
    });
  });
});

module.exports = router;
