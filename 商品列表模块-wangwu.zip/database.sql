-- ============================================
-- 校园闲置交易小程序 - 数据库初始化脚本
-- 直接在 MySQL 里整段执行即可
-- ============================================

CREATE DATABASE IF NOT EXISTS campus_trade DEFAULT CHARACTER SET utf8mb4;
USE campus_trade;

-- 商品表
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '商品主键ID',
  `title` varchar(100) NOT NULL COMMENT '商品标题',
  `description` text COMMENT '商品详情描述',
  `price` decimal(10,2) NOT NULL COMMENT '商品价格',
  `image` varchar(255) DEFAULT NULL COMMENT '商品封面图地址',
  `category_id` int DEFAULT NULL COMMENT '所属分类ID',
  `user_id` int NOT NULL COMMENT '发布者用户ID',
  `status` tinyint DEFAULT '1' COMMENT '商品状态：1-上架 0-下架',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='闲置商品表';

-- 分类表
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `category` (`name`) VALUES
('书籍教材'), ('数码电子'), ('宿舍用品'), ('服饰鞋包');

-- 测试商品数据
INSERT INTO `goods` (`title`, `description`, `price`, `image`, `category_id`, `user_id`) VALUES
('九成新考研数学教材', '2025版李永乐复习全书，无笔记', 25.00, 'https://img0.baidu.com/it/u=123&fm=253', 1, 1),
('闲置蓝牙耳机', '红米Buds 4，用了3个月，功能正常', 80.00, 'https://img0.baidu.com/it/u=456&fm=253', 2, 2),
('宿舍床上书桌', '可折叠，几乎全新，毕业带不走', 15.00, 'https://img0.baidu.com/it/u=789&fm=253', 3, 1),
('专业课本 计算机网络', '谢希仁第8版，少量划线', 12.00, 'https://img0.baidu.com/it/u=101&fm=253', 1, 3),
('机械键盘 青轴', 'RK84键，换轴闲置，手感好', 120.00, 'https://img0.baidu.com/it/u=202&fm=253', 2, 2),
('女生宿舍小台灯', '可充电，三档调光，成色新', 20.00, 'https://img0.baidu.com/it/u=303&fm=253', 3, 4),
('Python编程从入门到实践', '第二版，几乎全新，自学闲置', 35.00, 'https://img0.baidu.com/it/u=404&fm=253', 1, 2),
('九成新运动鞋', '42码，耐克，穿过几次，便宜出', 150.00, 'https://img0.baidu.com/it/u=505&fm=253', 4, 1),
('充电宝 20000毫安', '罗马仕，支持快充，无损坏', 45.00, 'https://img0.baidu.com/it/u=606&fm=253', 2, 3),
('宿舍收纳箱 大号', '塑料透明，带轮子，两个一起出', 30.00, 'https://img0.baidu.com/it/u=707&fm=253', 3, 4),
('Java核心技术 卷一', '第11版，厚本，少量笔记', 40.00, 'https://img0.baidu.com/it/u=808&fm=253', 1, 5),
('闲置卫衣', 'M码，灰色，宽松版型，没穿几次', 35.00, 'https://img0.baidu.com/it/u=909&fm=253', 4, 2);
